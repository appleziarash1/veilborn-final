# VEILBORN FINAL ART PACK

All required filename slots from ART_GUIDE.md are populated at the requested dimensions.

Some assets are production-ready crops/derivatives from the generated VEILBORN master art atlas so the package remains lightweight and follows the exact directory contract.
