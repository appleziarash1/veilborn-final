# VEILBORN — Animation & Movement Architecture v2

This package is structured so gameplay state is independent from visual state.

## Arena lock
Logical canvas: 1280×720.
Arena: x=60, y=150, width=1160, height=500.

All actors must clamp their **center position** against the arena bounds minus half-width/half-height. Dash uses the same clamp; it cannot bypass the boundary.

## Player states
`idle`, `run`, `attack`, `dash`, `hurt`, `death`

Attack is not the movement animation. Dash is not run. Hurt/death are terminal or interrupt states.

## Enemy states
Every enemy uses:
`idle`, `move`, `attack_windup`, `attack_active`, `attack_recovery`, `hurt`, `death`.

Movement and attack must never share a sprite row/file. Attack hitboxes are enabled only during `attack_active`.

## Boss states
`idle`, `move`, `attack_1`, `attack_2`, `special`, `hit`, `phase_change`, `death`.

## Runtime rule
Animation state changes must not change world position directly. Movement code owns position; animation code only selects frames/visual effects.

## Current pack
The original 52-slot art pack remains intact. The `game/index.html` is a runnable technical demo showing the corrected boundary/state architecture using the existing art. The newly generated expanded animation sheets were generated externally but are not embedded because their temporary hosted URLs are not stable package files.
